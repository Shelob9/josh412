#

## Development

- `npm i`
- `npm run start`

## Release

- Find and replace current version with new
- `npm run plugin:zip`
- `bun run uploadBuild.ts`
