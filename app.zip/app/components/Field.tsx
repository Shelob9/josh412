import Label from "./Label";

export default function Field({
	label,
	id,
	children
}:{
	label:string;
	id:string;
	children:React.ReactNode;
}) {
	return (
	  <div>
		<Label id={id}>{label}</Label>
		<div className="mt-2">
		  {children}
		</div>
	  </div>
	)
  }
