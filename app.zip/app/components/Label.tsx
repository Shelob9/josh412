export default function Label({id,children}:{id:string,children:string|React.ReactNode}) {
	return (
		<label htmlFor={id} className="block text-sm/6 font-medium text-gray-900 dark:text-white">
		  {children}
		</label>
	)
}
