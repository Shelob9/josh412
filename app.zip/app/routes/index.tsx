import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import Searchable from '~/components/Searchable'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  const [value, setValue] = useState<{ id: number, label: string } | undefined>(undefined)
  return (
    <div className="p-2">
      <h3>Welcome Home!!!</h3>
      <Searchable
        options={[
          { id: 1, label: 'Leslie Alexander' },
          {id: 2, label: 'Tacos Burriots'},
          {id: 3, label: 'Los Tacos'},

        ]}
        value={value}
        setValue={setValue}

      />
      {value ? (<p className='text-white bg-black'>{value.id}</p>) : <p>None</p>}

    </div>
  )
}
