import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Button } from '~/components/button'
import { Checkbox } from '~/components/checkbox'
import { Divider } from '~/components/divider'
import Field from '~/components/Field'
import Searchable from '~/components/Searchable'
import { Select, SelectOptions } from '~/components/select'

export const Route = createFileRoute('/form')({
  component: Home,
})

function Home() {
  const [value, setValue] = useState<{ id: number; label: string } | undefined>(
    undefined,
  )
  const [values,setValues]= useState<{type: 'bug'|'feature',enabled:boolean}>({type:'bug',enabled:true})
  const handler = (e) =>{
    e.preventDefault()
    console.log('Form submitted', { value, values })
  }
  return (
    <div className="p-2">
      <h3>Form Demo</h3>
      <div>
        <ul>
          <li>Assigned to: {value?.label}</li>
          <li>Type: {values.type}</li>
          <li>Enabled: {values.enabled ? 'Yes' : 'No'}</li>
        </ul>
      </div>
      <Divider />
      <form onSubmit={handler}>
        <Field label="Assigned to" id="assigned-to">
          <Searchable
            options={[
              { id: 1, label: 'Leslie Alexander' },
              { id: 2, label: 'Tacos Burriots' },
              { id: 3, label: 'Los Tacos' },
            ]}
            value={value}
            setValue={setValue}
            id="assigned-to"
          />
        </Field>
        <Field
          id="type"
          label="Type"
        >
          <Select
            id="type"
            value={values.type}
            onChange={(e) => {
              setValues((prev) => ({ ...prev, type: e.target.value as 'bug' | 'feature' }))
            }}
          >
            <SelectOptions options={[
              { value: 'bug', label: 'Bug' },
              { value: 'feature', label: 'Feature' },
            ]}/>
          </Select>
        </Field>
        <Field label="Enable" id="enabled">
          <Checkbox
            id={"enabled"}
            checked={values.enabled}
            onChange={(e) => {
              setValues((prev) => ({ ...prev, enabled: ! prev.enabled }))
            }}
          />

        </Field>
        <Button
          onClick={handler}
        >
          Save
        </Button>
      </form>

    </div>
  )
}
