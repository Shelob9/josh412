import { createAPIFileRoute } from '@tanstack/start/api'
import PDFDocument from 'pdfkit'
export const APIRoute = createAPIFileRoute('/api/pdf')({
  GET: async () => {
    const doc = new PDFDocument();
    doc.text('Hello world!', 100, 100)
    doc.end()
    // @ts-ignore
    return new Response(doc,{
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename="example.pdf"',
      },
    })
  },
})
